import openai

class gpt:
    '''
    Interacts with LLM API to make requests.
    Inputs depend on model used (currently only OpenAI GPT-4)
    Output is message content as a string.
    '''
    def __init__(self):
        pass

    def summary(personality, prompt):
        '''
        Makes request to OpenAI GPT-4
        Output is message content as a string
        '''
        completion = openai.ChatCompletion.create(
        model="gpt-3.5-turbo-16k",
        messages=[
            {"role": "user", "content": personality},
            {"role": "user", "content": prompt}
        ]
        )
        response = completion.choices[0].message
        return str(response["content"])